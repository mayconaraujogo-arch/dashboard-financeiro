# Finanças V4 - Login Google

## Novidades
- Login com Google
- Nome muda para o primeiro nome de quem logou
- Dados separados por usuário
- Regras seguras no Firestore

## Passos no Firebase
1. Firebase > Build > Authentication
2. Get started
3. Sign-in method
4. Ative Google
5. Firebase > Firestore > Regras
6. Use o conteúdo de `firestore-rules.txt`

## GitHub
Suba todos os arquivos desta pasta por cima dos antigos.
Depois atualize o site com Ctrl+F5.
